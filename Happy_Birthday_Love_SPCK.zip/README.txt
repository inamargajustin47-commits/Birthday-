HAPPY BIRTHDAY LOVE — SPCK FILES

Put these files in the same folder:
index.html
photo1.jpg ... photo9.jpg
birthday-video.mp4

The website is already coded to use those exact filenames.

Important:
- Rename your photos exactly to photo1.jpg through photo9.jpg.
- Rename your video exactly to birthday-video.mp4.
- Then open index.html in SPCK Preview.

To turn it into a public link, upload the whole folder to a web host such as GitHub Pages.
